package com.reins.bookstore.service;

import com.reins.bookstore.entity.Record;

import java.util.List;


public interface RecordService {

//    Record findBookById(Integer id);

    List<Record> getRecords();
    void addRecord(Record record);
    void delRecord(Record record);
}
