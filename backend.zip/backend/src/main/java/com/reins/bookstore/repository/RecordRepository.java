package com.reins.bookstore.repository;

import com.reins.bookstore.entity.Record;
import org.hibernate.annotations.Index;
import org.hibernate.annotations.SQLInsert;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import javax.transaction.Transactional;
import java.math.BigInteger;
import java.util.List;

public interface RecordRepository extends JpaRepository<Record,Integer> {

    @Query("select b from Record b")
    List<Record> getRecords();

//    @SQLInsert(sql="insert INTO `record` VALUES (10,10,10,10);")
    @Transactional
    @Modifying
    @Query(value="insert INTO `record` VALUES (:id,:date,:commodity,:price,:source);",nativeQuery = true)
    void addRecord(
            @Param("id")BigInteger id,
            @Param("date")String date,
            @Param("commodity")String commodity,
            @Param("price")Integer price,
            @Param("source")String source
    );

//    @Transactional
//    @Modifying
//    @Query(value="delete from `record` where id = :id;",nativeQuery = true)
//    void delRecord(
//            @Param("id")BigInteger id
//    );

}
