package com.reins.bookstore.controller;
import com.reins.bookstore.entity.Book;
import com.reins.bookstore.entity.Record;
import com.reins.bookstore.service.RecordService;
import com.sun.org.apache.bcel.internal.generic.ACONST_NULL;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;


@RestController
public class RecordController {

    @Autowired
    private RecordService recordService;

    @RequestMapping("/getRecords")
    public List<Record> getRecords() {
        return recordService.getRecords();
    }

    @RequestMapping("/addRecord")
    public void addRecord(
            @RequestBody Record record
    ) {
        record.setId();
        System.out.println(record);
        recordService.addRecord(record);
    }
    @RequestMapping("/delRecord")
    public void delRecord(
            @RequestBody Record record
    ) {
        record.setId();
        System.out.println(record);
        recordService.delRecord(record);
    }

//    @RequestMapping("/getBook")
//    public Record getBook(@RequestParam("id") Integer id){
//        return bookService.findBookById(id);
//    }
}
