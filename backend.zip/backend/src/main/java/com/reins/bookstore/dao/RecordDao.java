package com.reins.bookstore.dao;

import com.reins.bookstore.entity.Record;

import java.util.List;

public interface RecordDao {
//    Book findOne(Integer id);

    List<Record> getRecords();
    void addRecord(Record record);
    void delRecord(Record record);
}
