package com.reins.bookstore.entity;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.Data;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.math.BigInteger;


@Data
@Entity
@Table(name = "record")
@JsonIgnoreProperties(value = {"handler","hibernateLazyInitializer","fieldHandler"})
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class,property = "recordId")
public class Record {

    @Id
    @Column(name = "id")
    private BigInteger recordId;

    private String date;
    private String commodity;
    private Integer price;
    private String source;

    public void setId() {
        this.recordId = new BigInteger(this.date);
    }
}
