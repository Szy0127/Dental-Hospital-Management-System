package com.reins.bookstore.daoimpl;

import com.reins.bookstore.dao.RecordDao;
import com.reins.bookstore.entity.Record;
import com.reins.bookstore.repository.RecordRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public class RecordDaolmpl implements RecordDao {

    @Autowired
    private RecordRepository recordRepository;

//    @Override
//    public Record findOne(Integer id){
//        return recordRepository.getOne(id);
//    }


    @Override
    public List<Record> getRecords() {
        return recordRepository.getRecords();
    }
    @Override
    public void addRecord(Record record) {
        recordRepository.addRecord(
                record.getRecordId(),
                record.getDate(),
                record.getCommodity(),
                record.getPrice(),
                record.getSource()
        );
    }
    @Override
    public void delRecord(Record record) {
        System.out.println(record);
        recordRepository.delete(record);
//        recordRepository.delRecord(
//                record.getRecordId()
//        );
    }



}
